# RA ELI Café GTA — Android

Proyecto Android preparado para compilar con GitHub Actions.

## Qué contiene
- La escena HTML de RA ELI Café GTA incluida dentro del APK.
- El escenario y el vídeo están incrustados en el HTML, por lo que la aplicación no necesita descargar esos recursos.
- WebView a pantalla completa y orientación horizontal.
- Controles táctiles y controles de teclado ya incluidos en la escena.
- Workflow `.github/workflows/build-apk.yml` para generar automáticamente el APK.

## Cómo obtener el APK
1. Sube todos los archivos de esta carpeta a un repositorio nuevo de GitHub.
2. Abre la pestaña **Actions**.
3. Selecciona **Build RA ELI Café GTA APK**.
4. Pulsa **Run workflow**.
5. Cuando termine, abre la ejecución y descarga el artefacto **RA-Eli-Cafe-GTA-debug-apk**.
6. Dentro encontrarás `app-debug.apk` para instalarlo en Android.

## Requisitos
- GitHub Actions.
- JDK 17.
- Android SDK 35.
- Gradle 8.7.
